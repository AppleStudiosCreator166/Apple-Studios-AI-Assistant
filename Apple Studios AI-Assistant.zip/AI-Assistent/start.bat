@echo off
chcp 65001 > nul
javac ASJavaEngine.java
java ASJavaEngine
pause
