import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class ASJavaEngine {
    private static String currentLang = "RUS";
    private static JFrame frame;
    private static CardLayout cardLayout = new CardLayout();
    private static JPanel mainPanel = new JPanel(cardLayout);
    private static JTextArea chatArea = new JTextArea();
    private static JTextField inputField = new JTextField();
    private static JButton btnGoToAi, btnPaint, btnExit, btnLangToggle, btnSettings, btnBackFromSet, btnThemeToggle, sendButton, homeButton, btnCreateDraw, galleryToHomeBtn, btnClear;
    private static JLabel homeTitle, logoLabel, aiHeaderLabel, galleryTitleLabel, settingsTitleLabel;
    private static JPanel drawingsListPanel, homePanel, aiPanel, galleryPanel, settingsPanel; 
    private static boolean isFirstLaunch = true; 
    private static boolean isWhiteTheme = false;

    private static final Map<String, String> dynamicMemory = new HashMap<>();
    private static final Map<String, String> langPack = new HashMap<>(); 
    private static final String MEMORY_FILE = "memory.txt"; 
    private static final String LANG_FILE = "lang.txt"; 
    private static final String PICS_DIR = "Pictures"; 

    public static void main(String[] args) {
        loadMemoryFromFile(); loadLanguageFile(); 
        File dir = new File(PICS_DIR); if (!dir.exists()) dir.mkdir();

        SwingUtilities.invokeLater(() -> {
            frame = new JFrame("Apples Studios AI-Assistent v1.0.3");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(580, 580); frame.setLocationRelativeTo(null);

            homePanel = new JPanel(new GridBagLayout()); 
            GridBagConstraints gbc = new GridBagConstraints(); gbc.insets = new Insets(8, 8, 8, 8); gbc.gridx = 0;

            homeTitle = new JLabel(); homeTitle.setFont(new Font("Segoe UI", Font.BOLD, 26));
            homeTitle.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(0, 180, 216), 2), BorderFactory.createEmptyBorder(5, 15, 5, 15)));
            gbc.gridy = 0; homePanel.add(homeTitle, gbc);

            logoLabel = new JLabel(new ImageIcon(new ImageIcon("logo.png").getImage().getScaledInstance(120, 120, Image.SCALE_SMOOTH)));
            gbc.gridy = 1; homePanel.add(logoLabel, gbc);

            btnGoToAi = new JButton(); btnGoToAi.setFont(new Font("Segoe UI", Font.BOLD, 16));
            btnGoToAi.setPreferredSize(new Dimension(240, 40));
            btnGoToAi.addActionListener(x -> cardLayout.show(mainPanel, "AI")); gbc.gridy = 2; homePanel.add(btnGoToAi, gbc);
            btnPaint = new JButton(); btnPaint.setFont(new Font("Segoe UI", Font.BOLD, 16));
            btnPaint.setForeground(Color.BLACK); btnPaint.setPreferredSize(new Dimension(240, 40));
            btnPaint.addActionListener(x -> { refreshGalleryList(); cardLayout.show(mainPanel, "GALLERY"); });
            gbc.gridy = 3; homePanel.add(btnPaint, gbc);

            btnExit = new JButton(); btnExit.setFont(new Font("Segoe UI", Font.BOLD, 16));
            btnExit.setForeground(Color.WHITE); btnExit.setPreferredSize(new Dimension(240, 40));
            btnExit.addActionListener(x -> System.exit(0)); gbc.gridy = 4; homePanel.add(btnExit, gbc);

            JPanel bottomRowPanel = new JPanel(new BorderLayout());
            bottomRowPanel.setOpaque(false); bottomRowPanel.setPreferredSize(new Dimension(240, 30)); 

            btnSettings = new JButton(); btnSettings.setFont(new Font("Segoe UI", Font.BOLD, 11));
            btnSettings.setPreferredSize(new Dimension(110, 26));
            btnSettings.addActionListener(x -> cardLayout.show(mainPanel, "SETTINGS"));
            bottomRowPanel.add(btnSettings, BorderLayout.WEST);

            btnLangToggle = new JButton(); btnLangToggle.setFont(new Font("Segoe UI", Font.BOLD, 11));
            btnLangToggle.setPreferredSize(new Dimension(110, 26));
            btnLangToggle.addActionListener(x -> { if (currentLang.equals("RUS")) switchLang("ENG"); else switchLang("RUS"); });
            bottomRowPanel.add(btnLangToggle, BorderLayout.EAST);

            gbc.gridy = 5; gbc.insets = new Insets(20, 8, 8, 8); homePanel.add(bottomRowPanel, gbc);

            settingsPanel = new JPanel(new GridBagLayout()); 
            GridBagConstraints sGbc = new GridBagConstraints(); sGbc.insets = new Insets(12, 12, 12, 12); sGbc.gridx = 0;

            settingsTitleLabel = new JLabel(); settingsTitleLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
            sGbc.gridy = 0; settingsPanel.add(settingsTitleLabel, sGbc);

            btnThemeToggle = new JButton(); btnThemeToggle.setFont(new Font("Segoe UI", Font.BOLD, 14));
            btnThemeToggle.setPreferredSize(new Dimension(240, 40));
            btnThemeToggle.addActionListener(x -> toggleAppTheme()); sGbc.gridy = 1; settingsPanel.add(btnThemeToggle, sGbc);

            btnBackFromSet = new JButton(); btnBackFromSet.setFont(new Font("Segoe UI", Font.BOLD, 14));
            btnBackFromSet.setPreferredSize(new Dimension(240, 40));
            btnBackFromSet.addActionListener(x -> cardLayout.show(mainPanel, "HOME")); sGbc.gridy = 2; settingsPanel.add(btnBackFromSet, sGbc);

            aiPanel = new JPanel(new BorderLayout(10, 10)); aiPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
            JPanel aih = new JPanel(new BorderLayout(10, 10)); aih.setOpaque(false);
            
            homeButton = new JButton(); homeButton.setPreferredSize(new Dimension(80, 25)); homeButton.addActionListener(x -> cardLayout.show(mainPanel, "HOME"));
            btnClear = new JButton(); btnClear.setPreferredSize(new Dimension(80, 25)); btnClear.addActionListener(x -> chatArea.setText(""));
            
            JPanel aiTopButtons = new JPanel(new GridLayout(1, 2, 5, 0)); aiTopButtons.setOpaque(false);
            aiTopButtons.add(homeButton); aiTopButtons.add(btnClear);
            aiHeaderLabel = new JLabel("", SwingConstants.CENTER); aiHeaderLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
            aih.add(aiTopButtons, BorderLayout.WEST); aih.add(aiHeaderLabel, BorderLayout.CENTER); aiPanel.add(aih, BorderLayout.NORTH);

            chatArea.setFont(new Font("Consolas", Font.PLAIN, 14)); chatArea.setEditable(false);
            chatArea.setLineWrap(true); chatArea.setWrapStyleWord(true); aiPanel.add(new JScrollPane(chatArea), BorderLayout.CENTER);

            JPanel bp = new JPanel(new BorderLayout(10, 10)); bp.setOpaque(false);
            inputField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            sendButton = new JButton(); sendButton.addActionListener(x -> sendMsg()); inputField.addActionListener(x -> sendMsg());
            bp.add(inputField, BorderLayout.CENTER); bp.add(sendButton, BorderLayout.EAST); aiPanel.add(bp, BorderLayout.SOUTH);
            galleryPanel = new JPanel(new BorderLayout(15, 15)); galleryPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
            JPanel galleryHeader = new JPanel(new BorderLayout(10, 10)); galleryHeader.setOpaque(false);
            
            galleryToHomeBtn = new JButton(); galleryToHomeBtn.setPreferredSize(new Dimension(80, 25)); galleryToHomeBtn.addActionListener(x -> cardLayout.show(mainPanel, "HOME"));
            galleryTitleLabel = new JLabel("", SwingConstants.CENTER); galleryTitleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
            galleryHeader.add(galleryToHomeBtn, BorderLayout.WEST); galleryHeader.add(galleryTitleLabel, BorderLayout.CENTER);
            galleryPanel.add(galleryHeader, BorderLayout.NORTH);

            drawingsListPanel = new JPanel(); drawingsListPanel.setLayout(new BoxLayout(drawingsListPanel, BoxLayout.Y_AXIS));
            JScrollPane galleryScroll = new JScrollPane(drawingsListPanel); galleryPanel.add(galleryScroll, BorderLayout.CENTER);

            btnCreateDraw = new JButton(); btnCreateDraw.setFont(new Font("Segoe UI", Font.BOLD, 14)); btnCreateDraw.addActionListener(x -> createNewDrawingProcess());
            galleryPanel.add(btnCreateDraw, BorderLayout.SOUTH);

            mainPanel.add(homePanel, "HOME"); mainPanel.add(aiPanel, "AI"); mainPanel.add(galleryPanel, "GALLERY"); mainPanel.add(settingsPanel, "SETTINGS");
            frame.add(mainPanel); updateThemeStyles(); switchLang("RUS"); frame.setVisible(true);
        });
    }

    private static void toggleAppTheme() {
        isWhiteTheme = !isWhiteTheme; updateThemeStyles(); frame.repaint();
    }

    private static void updateThemeStyles() {
        Color bg = isWhiteTheme ? new Color(240, 243, 246) : new Color(13, 27, 42);
        Color panelBg = isWhiteTheme ? new Color(255, 255, 255) : new Color(27, 38, 59);
        Color text = isWhiteTheme ? new Color(20, 30, 40) : Color.WHITE;
        Color neonBlue = isWhiteTheme ? new Color(0, 119, 182) : new Color(0, 180, 216);

        homePanel.setBackground(bg); aiPanel.setBackground(bg); galleryPanel.setBackground(bg); settingsPanel.setBackground(bg);
        drawingsListPanel.setBackground(panelBg); chatArea.setBackground(panelBg); inputField.setBackground(panelBg);
        homeTitle.setForeground(neonBlue); settingsTitleLabel.setForeground(neonBlue); aiHeaderLabel.setForeground(neonBlue);
        chatArea.setForeground(text); inputField.setForeground(text);

        btnGoToAi.setBackground(neonBlue); btnGoToAi.setForeground(isWhiteTheme ? Color.WHITE : Color.BLACK);
        btnPaint.setBackground(isWhiteTheme ? new Color(255, 183, 77) : new Color(255, 159, 67));
        btnExit.setBackground(new Color(230, 57, 70)); btnClear.setBackground(new Color(230, 57, 70));
        
        btnSettings.setBackground(isWhiteTheme ? new Color(144, 224, 239) : new Color(0, 150, 199));
        btnSettings.setForeground(isWhiteTheme ? Color.BLACK : Color.WHITE);
        btnLangToggle.setBackground(isWhiteTheme ? new Color(144, 224, 239) : new Color(27, 38, 59));
        btnLangToggle.setForeground(isWhiteTheme ? Color.BLACK : Color.LIGHT_GRAY);

        btnThemeToggle.setBackground(panelBg); btnThemeToggle.setForeground(text);
        btnBackFromSet.setBackground(neonBlue); btnBackFromSet.setForeground(isWhiteTheme ? Color.WHITE : Color.BLACK);
        homeButton.setBackground(neonBlue); homeButton.setForeground(isWhiteTheme ? Color.WHITE : Color.BLACK);
        galleryToHomeBtn.setBackground(neonBlue); galleryToHomeBtn.setForeground(isWhiteTheme ? Color.WHITE : Color.BLACK);
        btnCreateDraw.setBackground(neonBlue); sendButton.setBackground(neonBlue);
    }
    private static void createNewDrawingProcess() {
        JPanel panel = new JPanel(new BorderLayout(5, 5));
        JLabel msg = new JLabel(currentLang.equals("RUS") ? "Введите название вашего рисунка:" : "Enter drawing title:");
        JTextField nameInput = new JTextField(15); panel.add(msg, BorderLayout.NORTH); panel.add(nameInput, BorderLayout.SOUTH);
        Object[] customButtons = currentLang.equals("RUS") ? new Object[]{"Создать", "Отмена"} : new Object[]{"Create", "Cancel"};
        int result = JOptionPane.showOptionDialog(frame, panel, getTxt("inputTitle"), JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, customButtons, customButtons);
        if (result != JOptionPane.OK_OPTION) return;

        String drawName = nameInput.getText().trim(); if (drawName.isEmpty()) return;
        String finalJpgName = drawName + ".jpg"; File imageFile = new File(PICS_DIR + File.separator + finalJpgName);
        if (!imageFile.exists()) {
            try {
                java.awt.image.BufferedImage emptyImg = new java.awt.image.BufferedImage(800, 600, java.awt.image.BufferedImage.TYPE_INT_RGB);
                Graphics2D g = emptyImg.createGraphics(); g.setColor(Color.WHITE); g.fillRect(0, 0, 800, 600); g.dispose();
                javax.imageio.ImageIO.write(emptyImg, "jpg", imageFile);
            } catch (IOException e) {}
        }
        refreshGalleryList(); openPaintAndWatch(imageFile);
    }

    private static void openPaintAndWatch(File imageFile) {
        new Thread(() -> { try { Process p = Runtime.getRuntime().exec("mspaint.exe \"" + imageFile.getAbsolutePath() + "\""); p.waitFor(); SwingUtilities.invokeLater(() -> refreshGalleryList()); } catch (Exception ex) {} }).start();
    }

    private static void refreshGalleryList() {
        drawingsListPanel.removeAll(); File folder = new File(PICS_DIR); File[] files = folder.listFiles((dir, name) -> name.toLowerCase().endsWith(".jpg"));
        if (files != null) {
            for (File f : files) {
                String filename = f.getName(); JPanel rowPanel = new JPanel(new BorderLayout(5, 0)); rowPanel.setMaximumSize(new Dimension(530, 40));
                rowPanel.setBackground(isWhiteTheme ? new Color(255,255,255) : new Color(27, 38, 59));
                JButton imgButton = new JButton(filename); imgButton.setBackground(isWhiteTheme ? new Color(240,243,246) : new Color(13, 27, 42)); imgButton.setForeground(isWhiteTheme ? Color.BLACK : Color.WHITE);
                imgButton.addActionListener(x -> showImagePopup(f));
                rowPanel.add(imgButton, BorderLayout.CENTER); drawingsListPanel.add(rowPanel); drawingsListPanel.add(Box.createRigidArea(new Dimension(0, 5)));
            }
        }
        drawingsListPanel.revalidate(); drawingsListPanel.repaint();
    }

    private static void showImagePopup(File file) {
        JDialog viewer = new JDialog(frame, file.getName(), true); viewer.setSize(500, 500); viewer.setLocationRelativeTo(frame); viewer.getContentPane().setBackground(new Color(13, 27, 42));
        ImageIcon imgIcon = new ImageIcon(file.getAbsolutePath()); Image scaledImg = imgIcon.getImage().getScaledInstance(450, 400, Image.SCALE_SMOOTH); JLabel imgLabel = new JLabel(new ImageIcon(scaledImg), SwingConstants.CENTER);
        JButton closeBtn = new JButton(currentLang.equals("RUS") ? "Назад" : "Back"); closeBtn.setBackground(new Color(230, 57, 70)); closeBtn.setForeground(Color.WHITE); closeBtn.addActionListener(e -> viewer.dispose());
        viewer.add(imgLabel, BorderLayout.CENTER); viewer.add(closeBtn, BorderLayout.SOUTH); viewer.setVisible(true);
    }

    private static void sendMsg() {
        String txt = inputField.getText().trim(); if (txt.isEmpty()) return;
        chatArea.append("You: " + txt + "\n"); inputField.setText(""); String lowerTxt = txt.toLowerCase();
        if (txt.contains(" - ")) {
            String[] parts = txt.split(" - ", 2); String k = parts[0].trim().toLowerCase(); String v = parts[1].trim();
            dynamicMemory.put(k, v); saveWordToFile(k, v); chatArea.append("ИИ: " + (currentLang.equals("RUS") ? "Запомнил!" : "Saved!") + "\n\n"); return;
        }
        chatArea.append(currentLang.equals("RUS") ? "ИИ: Думаю над запросом (таймер 20 секунд)..." : "AI: Processing request (20s timer)...");
        new Thread(() -> {
            try { Thread.sleep(20000); } catch (Exception e) {}
            String aiResponse = dynamicMemory.containsKey(lowerTxt) ? "ИИ (Из словаря базы знаний):\n" + dynamicMemory.get(lowerTxt) : "Критическая ошибка загрузки: ответ не получен за 20 секунд.";
            SwingUtilities.invokeLater(() -> chatArea.append("\n" + aiResponse + "\n\n"));
        }).start();
    }

    private static void saveWordToFile(String key, String value) {
        try (FileWriter fw = new FileWriter(MEMORY_FILE, true); PrintWriter out = new PrintWriter(new BufferedWriter(fw))) { out.println(key + ":::" + value); } catch (IOException e) {}
    }

    private static void loadMemoryFromFile() {
        File file = new File(MEMORY_FILE); if (!file.exists()) return; 
        try (Scanner scanner = new Scanner(file, "UTF-8")) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                if (line.contains(":::")) { String[] parts = line.split(":::", 2); dynamicMemory.put(parts[0].trim().toLowerCase(), parts[1].trim()); }
            }
        } catch (Exception e) {}
    }

    private static void loadLanguageFile() {
        File file = new File(LANG_FILE); if (!file.exists()) return;
        try (Scanner scanner = new Scanner(file, "UTF-8")) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                if (line.contains(":::")) { String[] parts = line.split(":::", 2); langPack.put(parts[0].trim(), parts[1].trim()); }
            }
        } catch (Exception e) {}
    }

    private static String getTxt(String key) {
        if (langPack.containsKey(currentLang + "_" + key)) return langPack.get(currentLang + "_" + key);
        if (currentLang.equals("RUS")) {
            if (key.equals("homeTitle")) return "ГЛАВНАЯ СТРАНИЦА";
            if (key.equals("btnGoToAi")) return "Нейросеть";
            if (key.equals("btnPaint")) return "Студия Нарисуй!";
            if (key.equals("btnExit")) return "Выйти";
            if (key.equals("aiHeader")) return "НЕЙРОСЕТЬ APPLES STUDIOS";
            if (key.equals("homeButton")) return "Главная";
            if (key.equals("btnClear")) return "Очистить";
            if (key.equals("sendButton")) return "Спросить ИИ";
            if (key.equals("galleryTitle")) return "ГАЛЕРЕЯ РИСУНКОВ";
            if (key.equals("btnCreateDraw")) return "Создать Новый Рисунок";
            if (key.equals("welcome")) return "--- Мощный ИИ-Ассистент Apples Studios Alfa 1.0.3 успешно запущен! ---";
        } else {
            if (key.equals("homeTitle")) return "MAIN PAGE";
            if (key.equals("btnGoToAi")) return "AI-Network";
            if (key.equals("btnPaint")) return "Paint Studio!";
            if (key.equals("btnExit")) return "Exit";
            if (key.equals("aiHeader")) return "APPLES STUDIOS AI";
            if (key.equals("homeButton")) return "Home";
            if (key.equals("btnClear")) return "Clear";
            if (key.equals("sendButton")) return "Ask AI";
            if (key.equals("galleryTitle")) return "DRAWINGS GALLERY";
            if (key.equals("btnCreateDraw")) return "Create New Drawing";
            if (key.equals("welcome")) return "--- Powerful Apples Studios AI-Assistant Alfa 1.0.3 successfully launched! ---";
        }
        return "[" + key + "]";
    }

    private static void switchLang(String lang) {
        currentLang = lang; homeTitle.setText(getTxt("homeTitle")); btnGoToAi.setText(getTxt("btnGoToAi"));
        btnPaint.setText(getTxt("btnPaint")); btnExit.setText(getTxt("btnExit")); galleryTitleLabel.setText(getTxt("galleryTitle")); btnCreateDraw.setText(getTxt("btnCreateDraw"));
        homeButton.setText(getTxt("homeButton")); btnClear.setText(getTxt("btnClear")); sendButton.setText(getTxt("sendButton"));
        if (galleryToHomeBtn != null) galleryToHomeBtn.setText(getTxt("homeButton"));
        if (aiHeaderLabel != null) aiHeaderLabel.setText(getTxt("aiHeader"));
        if (btnSettings != null) btnSettings.setText(lang.equals("RUS") ? "Настройки" : "Settings");
        if (settingsTitleLabel != null) settingsTitleLabel.setText(lang.equals("RUS") ? "НАСТРОЙКИ СИСТЕМЫ" : "SYSTEM SETTINGS");
        if (btnThemeToggle != null) btnThemeToggle.setText(lang.equals("RUS") ? "Сменить Тему" : "Change Theme");
        if (btnBackFromSet != null) btnBackFromSet.setText(lang.equals("RUS") ? "Назад" : "Back");
        if (btnLangToggle != null) btnLangToggle.setText(lang.equals("RUS") ? "Язык: RUS" : "Lang: ENG");
        if (isFirstLaunch) { chatArea.setText(getTxt("welcome").replace("\\n", "\n")); isFirstLaunch = false; }
        refreshGalleryList(); 
    }
}
