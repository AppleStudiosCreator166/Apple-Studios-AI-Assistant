import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class ASJavaEngine {
    private static String currentLang = "RUS";
    private static JFrame frame;
    private static CardLayout cardLayout = new CardLayout();
    private static JPanel mainPanel = new JPanel(cardLayout);
    private static JTextArea chatArea = new JTextArea();
    private static JTextField inputField = new JTextField();
    private static JButton btnGoToAi, btnPaint, btnExit, btnLangToggle, btnSettings, btnBackFromSet, btnThemeToggle, btnExportMemory, btnPassport, btnStats, sendButton, homeButton, btnCreateDraw, galleryToHomeBtn, btnClear;
    private static JLabel homeTitle, logoLabel, aiHeaderLabel, galleryTitleLabel, settingsTitleLabel;
    private static JPanel drawingsListPanel, homePanel, aiPanel, galleryPanel, settingsPanel; 
    private static boolean isFirstLaunch = true, isWhiteTheme = false;

    private static final Map<String, String> dynamicMemory = new HashMap<>();
    private static final Map<String, String> langPack = new HashMap<>(); 
    private static final String MEMORY_FILE = "memory.txt", BACKUP_FILE = "memory_backup.txt", LANG_FILE = "lang.txt", PICS_DIR = "Pictures"; 

    public static void main(String[] args) {
        checkAndCreateLangFile(); loadMemoryFromFile(); loadLanguageFile(); 
        File dir = new File(PICS_DIR); if (!dir.exists()) dir.mkdir();

        SwingUtilities.invokeLater(() -> {
            // ОФИЦИАЛЬНЫЙ ТИТУЛ ВЕРСИИ 1.0.3
            frame = new JFrame("Apples Studios AI-Assistent v1.0.3");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); frame.setSize(580, 640); frame.setLocationRelativeTo(null);

            homePanel = new JPanel(new GridBagLayout()); GridBagConstraints gbc = new GridBagConstraints(); gbc.insets = new Insets(8, 8, 8, 8); gbc.gridx = 0;
            homeTitle = new JLabel(); homeTitle.setFont(new Font("Segoe UI", Font.BOLD, 26));
            homeTitle.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(0, 180, 216), 2), BorderFactory.createEmptyBorder(5, 15, 5, 15)));
            gbc.gridy = 0; homePanel.add(homeTitle, gbc);

            logoLabel = new JLabel(new ImageIcon(new ImageIcon("logo.png").getImage().getScaledInstance(120, 120, Image.SCALE_SMOOTH)));
            gbc.gridy = 1; homePanel.add(logoLabel, gbc);

            btnGoToAi = new JButton(); btnGoToAi.setFont(new Font("Segoe UI", Font.BOLD, 16)); btnGoToAi.setPreferredSize(new Dimension(240, 40));
            btnGoToAi.addActionListener(x -> cardLayout.show(mainPanel, "AI")); gbc.gridy = 2; homePanel.add(btnGoToAi, gbc);
            btnPaint = new JButton(); btnPaint.setFont(new Font("Segoe UI", Font.BOLD, 16)); btnPaint.setForeground(Color.BLACK); btnPaint.setPreferredSize(new Dimension(240, 40));
            btnPaint.addActionListener(x -> { refreshGalleryList(); cardLayout.show(mainPanel, "GALLERY"); }); gbc.gridy = 3; homePanel.add(btnPaint, gbc);

            btnExit = new JButton(); btnExit.setFont(new Font("Segoe UI", Font.BOLD, 16)); btnExit.setForeground(Color.WHITE); btnExit.setPreferredSize(new Dimension(240, 40));
            btnExit.addActionListener(x -> System.exit(0)); gbc.gridy = 4; homePanel.add(btnExit, gbc);

            JPanel bottomRowPanel = new JPanel(new BorderLayout()); bottomRowPanel.setOpaque(false); bottomRowPanel.setPreferredSize(new Dimension(240, 30)); 
            btnSettings = new JButton(); btnSettings.setFont(new Font("Segoe UI", Font.BOLD, 11)); btnSettings.setPreferredSize(new Dimension(110, 26));
            btnSettings.addActionListener(x -> cardLayout.show(mainPanel, "SETTINGS")); bottomRowPanel.add(btnSettings, BorderLayout.WEST);

            btnLangToggle = new JButton(); btnLangToggle.setFont(new Font("Segoe UI", Font.BOLD, 11)); btnLangToggle.setPreferredSize(new Dimension(110, 26));
            btnLangToggle.addActionListener(x -> { if (currentLang.equals("RUS")) switchLang("ENG"); else switchLang("RUS"); }); bottomRowPanel.add(btnLangToggle, BorderLayout.EAST);
            gbc.gridy = 5; gbc.insets = new Insets(20, 8, 8, 8); homePanel.add(bottomRowPanel, gbc);

            // СЕТКА НАСТРОЕК С ОФИЦИАЛЬНЫМ НАБОРОМ ФИЧ ПАТЧА 1.0.3
            settingsPanel = new JPanel(new GridBagLayout()); GridBagConstraints sGbc = new GridBagConstraints(); sGbc.insets = new Insets(6, 6, 6, 6); sGbc.gridx = 0;
            settingsTitleLabel = new JLabel(); settingsTitleLabel.setFont(new Font("Segoe UI", Font.BOLD, 22)); sGbc.gridy = 0; settingsPanel.add(settingsTitleLabel, sGbc);

            btnThemeToggle = new JButton(); btnThemeToggle.setFont(new Font("Segoe UI", Font.BOLD, 14)); btnThemeToggle.setPreferredSize(new Dimension(240, 40));
            btnThemeToggle.addActionListener(x -> { isWhiteTheme = !isWhiteTheme; updateThemeStyles(); frame.repaint(); }); sGbc.gridy = 1; settingsPanel.add(btnThemeToggle, sGbc);

            btnExportMemory = new JButton(); btnExportMemory.setFont(new Font("Segoe UI", Font.BOLD, 14)); btnExportMemory.setPreferredSize(new Dimension(240, 40));
            btnExportMemory.addActionListener(x -> exportMemoryBackup()); sGbc.gridy = 2; settingsPanel.add(btnExportMemory, sGbc);

            btnStats = new JButton(); btnStats.setFont(new Font("Segoe UI", Font.BOLD, 14)); btnStats.setPreferredSize(new Dimension(240, 40));
            btnStats.addActionListener(x -> showStatsWindow()); sGbc.gridy = 3; settingsPanel.add(btnStats, sGbc);

            btnPassport = new JButton(); btnPassport.setFont(new Font("Segoe UI", Font.BOLD, 14)); btnPassport.setPreferredSize(new Dimension(240, 40));
            btnPassport.addActionListener(x -> showPassportWindow()); sGbc.gridy = 4; settingsPanel.add(btnPassport, sGbc);

            btnBackFromSet = new JButton(); btnBackFromSet.setFont(new Font("Segoe UI", Font.BOLD, 14)); btnBackFromSet.setPreferredSize(new Dimension(240, 40));
            btnBackFromSet.addActionListener(x -> cardLayout.show(mainPanel, "HOME")); sGbc.gridy = 5; settingsPanel.add(btnBackFromSet, sGbc);

            aiPanel = new JPanel(new BorderLayout(10, 10)); aiPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
            JPanel aih = new JPanel(new BorderLayout(10, 10)); aih.setOpaque(false);
            homeButton = new JButton(); homeButton.setPreferredSize(new Dimension(80, 25)); homeButton.addActionListener(x -> cardLayout.show(mainPanel, "HOME"));
            btnClear = new JButton(); btnClear.setPreferredSize(new Dimension(80, 25)); btnClear.addActionListener(x -> chatArea.setText(""));
            JPanel aiTopButtons = new JPanel(new GridLayout(1, 2, 5, 0)); aiTopButtons.setOpaque(false); aiTopButtons.add(homeButton); aiTopButtons.add(btnClear);
            aiHeaderLabel = new JLabel("", SwingConstants.CENTER); aiHeaderLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
            aih.add(aiTopButtons, BorderLayout.WEST); aih.add(aiHeaderLabel, BorderLayout.CENTER); aiPanel.add(aih, BorderLayout.NORTH);

            chatArea.setFont(new Font("Consolas", Font.PLAIN, 14)); chatArea.setEditable(false); chatArea.setLineWrap(true); chatArea.setWrapStyleWord(true); aiPanel.add(new JScrollPane(chatArea), BorderLayout.CENTER);
            JPanel bp = new JPanel(new BorderLayout(10, 10)); bp.setOpaque(false); inputField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            sendButton = new JButton(); sendButton.addActionListener(x -> sendMsg()); inputField.addActionListener(x -> sendMsg());
            bp.add(inputField, BorderLayout.CENTER); bp.add(sendButton, BorderLayout.EAST); aiPanel.add(bp, BorderLayout.SOUTH);
            galleryPanel = new JPanel(new BorderLayout(15, 15)); galleryPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
            JPanel galleryHeader = new JPanel(new BorderLayout(10, 10)); galleryHeader.setOpaque(false);
            galleryToHomeBtn = new JButton(); galleryToHomeBtn.setPreferredSize(new Dimension(80, 25)); galleryToHomeBtn.addActionListener(x -> cardLayout.show(mainPanel, "HOME"));
            galleryTitleLabel = new JLabel("", SwingConstants.CENTER); galleryTitleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
            galleryHeader.add(galleryToHomeBtn, BorderLayout.WEST); galleryHeader.add(galleryTitleLabel, BorderLayout.CENTER);
            galleryPanel.add(galleryHeader, BorderLayout.NORTH);

            drawingsListPanel = new JPanel(); drawingsListPanel.setLayout(new BoxLayout(drawingsListPanel, BoxLayout.Y_AXIS));
            galleryPanel.add(new JScrollPane(drawingsListPanel), BorderLayout.CENTER);
            btnCreateDraw = new JButton(); btnCreateDraw.setFont(new Font("Segoe UI", Font.BOLD, 14)); btnCreateDraw.addActionListener(x -> createNewDrawingProcess());
            galleryPanel.add(btnCreateDraw, BorderLayout.SOUTH);

            mainPanel.add(homePanel, "HOME"); mainPanel.add(aiPanel, "AI"); mainPanel.add(galleryPanel, "GALLERY"); mainPanel.add(settingsPanel, "SETTINGS");
            frame.add(mainPanel); updateThemeStyles(); switchLang("RUS"); frame.setVisible(true);
        });
    }

    private static void showStatsWindow() {
        int wordCount = dynamicMemory.size();
        String msg = currentLang.equals("RUS") ? "📊 В базе сейчас " + wordCount + " слов!" : "📊 Current database size: " + wordCount + " words!";
        JOptionPane.showMessageDialog(frame, msg, currentLang.equals("RUS") ? "Статистика словаря" : "Dictionary Stats", JOptionPane.INFORMATION_MESSAGE);
    }

    private static void showPassportWindow() {
        String msg = "===============================\n  ПАСПОРТ ПРОГРАММЫ META-JAVA \n===============================\n\n 🏆 Компания: Apples Studios\n ⚙️ Программа: AI-Assistant Engine\n 💎 Версия ядра: Alfa 1.0.3\n 👑 Тимлид / Архитектор: Илья\n\n===============================\n       All rights reserved (c) 2026";
        JOptionPane.showMessageDialog(frame, msg, currentLang.equals("RUS") ? "Паспорт" : "Passport", JOptionPane.INFORMATION_MESSAGE);
    }

    private static void exportMemoryBackup() {
        File src = new File(MEMORY_FILE); if (!src.exists()) return;
        try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(src), "UTF-8"));
             BufferedWriter w = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File(BACKUP_FILE)), "UTF-8"))) {
            String line; while ((line = r.readLine()) != null) w.write(line + "\n");
            JOptionPane.showMessageDialog(frame, currentLang.equals("RUS") ? "Резервная копия создана!" : "Backup created!", "Apples Studios", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {}
    }

    private static void updateThemeStyles() {
        Color bg, panelBg, text, neonBlue, orangeNeon;
        if (isWhiteTheme) {
            bg = new Color(240, 243, 246); panelBg = new Color(255, 255, 255); text = new Color(20, 30, 40); neonBlue = new Color(0, 119, 182); orangeNeon = new Color(230, 108, 0);
        } else {
            bg = new Color(13, 27, 42); panelBg = new Color(27, 38, 59); text = Color.WHITE; neonBlue = new Color(0, 180, 216); orangeNeon = new Color(255, 159, 67);
        }
        homePanel.setBackground(bg); aiPanel.setBackground(bg); galleryPanel.setBackground(bg); settingsPanel.setBackground(bg);
        drawingsListPanel.setBackground(panelBg); chatArea.setBackground(panelBg); inputField.setBackground(panelBg);
        homeTitle.setForeground(neonBlue); settingsTitleLabel.setForeground(neonBlue); aiHeaderLabel.setForeground(neonBlue);
        chatArea.setForeground(text); inputField.setForeground(text); galleryTitleLabel.setForeground(orangeNeon);

        btnGoToAi.setBackground(neonBlue); btnGoToAi.setForeground(isWhiteTheme ? Color.WHITE : Color.BLACK);
        btnPaint.setBackground(isWhiteTheme ? new Color(255, 183, 77) : new Color(255, 159, 67));
        btnExit.setBackground(new Color(230, 57, 70)); btnClear.setBackground(new Color(230, 57, 70));
        btnSettings.setBackground(isWhiteTheme ? new Color(144, 224, 239) : new Color(0, 150, 199)); btnSettings.setForeground(isWhiteTheme ? Color.BLACK : Color.WHITE);
        btnLangToggle.setBackground(isWhiteTheme ? new Color(144, 224, 239) : new Color(27, 38, 59)); btnLangToggle.setForeground(isWhiteTheme ? Color.BLACK : Color.LIGHT_GRAY);
        btnThemeToggle.setBackground(panelBg); btnThemeToggle.setForeground(text); btnExportMemory.setBackground(panelBg); btnExportMemory.setForeground(text);
        btnPassport.setBackground(panelBg); btnPassport.setForeground(text); btnStats.setBackground(panelBg); btnStats.setForeground(text);
        btnBackFromSet.setBackground(neonBlue); btnBackFromSet.setForeground(isWhiteTheme ? Color.WHITE : Color.BLACK);
        homeButton.setBackground(neonBlue); homeButton.setForeground(isWhiteTheme ? Color.WHITE : Color.BLACK);
        galleryToHomeBtn.setBackground(neonBlue); galleryToHomeBtn.setForeground(isWhiteTheme ? Color.WHITE : Color.BLACK);
        btnCreateDraw.setBackground(neonBlue); sendButton.setBackground(neonBlue);
    }

    private static void createNewDrawingProcess() {
        String name = JOptionPane.showInputDialog(frame, currentLang.equals("RUS") ? "Название:" : "Title:"); if (name == null || name.trim().isEmpty()) return;
        File f = new File(PICS_DIR + File.separator + name.trim() + ".jpg");
        if (!f.exists()) {
            try { java.awt.image.BufferedImage img = new java.awt.image.BufferedImage(800, 600, java.awt.image.BufferedImage.TYPE_INT_RGB); Graphics2D g = img.createGraphics(); g.setColor(Color.WHITE); g.fillRect(0, 0, 800, 600); g.dispose(); javax.imageio.ImageIO.write(img, "jpg", f); } catch (IOException e) {}
        }
        refreshGalleryList(); openPaintAndWatch(f);
    }

    private static void openPaintAndWatch(File f) {
        new Thread(() -> { try { Runtime.getRuntime().exec("mspaint.exe \"" + f.getAbsolutePath() + "\"").waitFor(); SwingUtilities.invokeLater(() -> refreshGalleryList()); } catch (Exception ex) {} }).start();
    }

    private static void refreshGalleryList() {
        drawingsListPanel.removeAll(); File folder = new File(PICS_DIR); File[] files = folder.listFiles((dir, name) -> name.toLowerCase().endsWith(".jpg"));
        if (files != null) {
            for (File f : files) {
                JPanel row = new JPanel(new BorderLayout()); row.setMaximumSize(new Dimension(530, 40)); row.setBackground(isWhiteTheme ? Color.WHITE : new Color(27, 38, 59));
                JButton btn = new JButton(f.getName()); btn.setBackground(isWhiteTheme ? new Color(240,243,246) : new Color(13, 27, 42)); btn.setForeground(isWhiteTheme ? Color.BLACK : Color.WHITE);
                btn.addActionListener(x -> {
                    JDialog v = new JDialog(frame, f.getName(), true); v.setSize(500, 500); v.setLocationRelativeTo(frame);
                    v.add(new JLabel(new ImageIcon(new ImageIcon(f.getAbsolutePath()).getImage().getScaledInstance(450, 400, Image.SCALE_SMOOTH))), BorderLayout.CENTER);
                    JButton c = new JButton(currentLang.equals("RUS") ? "Назад" : "Back"); c.addActionListener(e -> v.dispose()); v.add(c, BorderLayout.SOUTH); v.setVisible(true);
                });
                row.add(btn, BorderLayout.CENTER); drawingsListPanel.add(row); drawingsListPanel.add(Box.createRigidArea(new Dimension(0, 5)));
            }
        }
        drawingsListPanel.revalidate(); drawingsListPanel.repaint();
    }

    private static void sendMsg() {
        String txt = inputField.getText().trim(); if (txt.isEmpty()) return;
        chatArea.append("You: " + txt + "\n"); inputField.setText(""); String lowerTxt = txt.toLowerCase();
        if (txt.contains(" - ")) {
            String[] parts = txt.split(" - ", 2); dynamicMemory.put(parts[0].trim().toLowerCase(), parts[1].trim());
            try (FileWriter fw = new FileWriter(MEMORY_FILE, true); PrintWriter out = new PrintWriter(new BufferedWriter(fw))) { out.println(parts[0].trim().toLowerCase() + ":::" + parts[1].trim()); } catch (IOException e) {}
            chatArea.append("ИИ: " + (currentLang.equals("RUS") ? "Запомнил!" : "Saved!") + "\n\n"); return;
        }
        chatArea.append(currentLang.equals("RUS") ? "ИИ: Думаю над запросом (таймер 20 секунд)..." : "AI: Processing request (20s timer)...");
        new Thread(() -> {
            try { Thread.sleep(20000); } catch (Exception e) {}
            String res = dynamicMemory.containsKey(lowerTxt) ? "ИИ (Из словаря):\n" + dynamicMemory.get(lowerTxt) : "Ответ не получен за 20 секунд.";
            SwingUtilities.invokeLater(() -> chatArea.append("\n" + res + "\n\n"));
        }).start();
    }

    private static void loadMemoryFromFile() {
        File file = new File(MEMORY_FILE); if (!file.exists()) return; 
        try (Scanner sc = new Scanner(file, "UTF-8")) {
            while (sc.hasNextLine()) { String ln = sc.nextLine(); if (ln.contains(":::")) { String[] p = ln.split(":::", 2); dynamicMemory.put(p[0].trim().toLowerCase(), p[1].trim()); } }
        } catch (Exception e) {}
    }

    private static void loadLanguageFile() {
        File file = new File(LANG_FILE); if (!file.exists()) return;
        try (Scanner sc = new Scanner(file, "UTF-8")) {
            while (sc.hasNextLine()) { String ln = sc.nextLine(); if (ln.contains(":::")) { String[] p = ln.split(":::", 2); langPack.put(p[0].trim(), p[1].trim()); } }
        } catch (Exception e) {}
    }

    private static void checkAndCreateLangFile() {
File file = new File(LANG_FILE); if (file.exists()) return;try (PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-8")))) {out.println("RUS_homeTitle:::ГЛАВНАЯ СТРАНИЦА\nENG_homeTitle:::MAIN PAGE");out.println("RUS_btnGoToAi:::Нейросеть\nENG_btnGoToAi:::AI-Network");out.println("RUS_btnPaint:::Студия Нарисуй!\nENG_btnPaint:::Paint Studio!");out.println("RUS_btnExit:::Выйти\nENG_btnExit:::Exit");out.println("RUS_aiHeader:::НЕЙРОСЕТЬ APPLES STUDIOS\nENG_aiHeader:::APPLES STUDIOS AI");out.println("RUS_homeButton:::Главная\nENG_homeButton:::Home");out.println("RUS_btnClear:::Очистить\nENG_btnClear:::Clear");out.println("RUS_sendButton:::Спросить ИИ\nENG_sendButton:::Ask AI");out.println("RUS_galleryTitle:::ГАЛЕРЕЯ РИСУНКОВ\nENG_galleryTitle:::DRAWINGS GALLERY");out.println("RUS_btnCreateDraw:::Создать Новый Рисунок\nENG_btnCreateDraw:::Create New Drawing");out.println("RUS_welcome:::--- Мощный ИИ-Ассистент Apples Studios Alfa 1.0.3 успешно запущен! ---\nENG_welcome:::--- Powerful Apples Studios AI-Assistant Alfa 1.0.3 successfully launched! ---");} catch (Exception e) {}}private static String getTxt(String k) { return langPack.getOrDefault(currentLang + "_" + k, "[" + k + "]"); }private static void switchLang(String lang) {currentLang = lang; homeTitle.setText(getTxt("homeTitle")); btnGoToAi.setText(getTxt("btnGoToAi"));btnPaint.setText(getTxt("btnPaint")); btnExit.setText(getTxt("btnExit")); galleryTitleLabel.setText(getTxt("galleryTitle"));homeButton.setText(getTxt("homeButton")); btnClear.setText(getTxt("btnClear")); sendButton.setText(getTxt("sendButton"));if (galleryToHomeBtn != null) galleryToHomeBtn.setText(getTxt("homeButton"));if (aiHeaderLabel != null) aiHeaderLabel.setText(getTxt("aiHeader"));if (btnSettings != null) btnSettings.setText(lang.equals("RUS") ? "Настройки" : "Settings");if (settingsTitleLabel != null) settingsTitleLabel.setText(lang.equals("RUS") ? "НАСТРОЙКИ СИСТЕМЫ" : "SYSTEM SETTINGS");if (btnThemeToggle != null) btnThemeToggle.setText(lang.equals("RUS") ? "Сменить Тему" : "Change Theme");if (btnBackFromSet != null) btnBackFromSet.setText(lang.equals("RUS") ? "Назад" : "Back");if (btnLangToggle != null) btnLangToggle.setText(lang.equals("RUS") ? "Язык: RUS" : "Lang: ENG");if (btnExportMemory != null) btnExportMemory.setText(lang.equals("RUS") ? "Экспорт памяти" : "Export memory");if (btnPassport != null) btnPassport.setText(lang.equals("RUS") ? "Показать паспорт" : "Show passport");if (btnStats != null) btnStats.setText(lang.equals("RUS") ? "Статистика словаря" : "Dictionary stats");if (isFirstLaunch) { chatArea.setText(getTxt("welcome").replace("\n", "\n")); isFirstLaunch = false; }refreshGalleryList();}}